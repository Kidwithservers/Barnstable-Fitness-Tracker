// JavaScript Document

mdc.ripple.MDCRipple.attachTo(document.querySelector('.foo-button'));
mdc.textField.MDCTextField.attachTo(document.querySelector('.username'));